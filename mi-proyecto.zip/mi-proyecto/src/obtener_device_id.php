<?php
require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

MercadoPago\SDK::setAccessToken($_ENV['ACCESS_TOKEN']);

$url = 'https://api.mercadopago.com/point/integration-api/devices?offset=0&limit=50';
$options = [
    "http" => [
        "header" => "Authorization: Bearer " . $_ENV['ACCESS_TOKEN']
    ]
];
$context = stream_context_create($options);
$response = file_get_contents($url, false, $context);

if ($response !== false) {
    $devices = json_decode($response, true);
    if (!empty($devices)) {
        echo "<h1>Dispositivos Point encontrados:</h1>";
        foreach ($devices as $device) {
            echo "<p>Device ID: " . $device['id'] . " | Modelo: " . $device['model'] . "</p>";
        }
    } else {
        echo "<p>No se encontraron dispositivos.</p>";
    }
} else {
    echo "<p>Error al obtener los dispositivos.</p>";
}
?>
