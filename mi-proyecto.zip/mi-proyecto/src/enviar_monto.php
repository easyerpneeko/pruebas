<?php
require __DIR__ . '/../vendor/autoload.php';

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

MercadoPago\SDK::setAccessToken($_ENV['ACCESS_TOKEN']);

$device_id = 'TU_DEVICE_ID'; // Reemplaza con tu device_id
$payment_data = [
    "amount" => 1000, // Monto en centavos (0.00 = 1000)
    "additional_info" => [
        "external_reference" => "transaccion-123",
        "print_on_terminal" => true
    ]
];

$response = MercadoPago\Point::createPaymentIntent($device_id, $payment_data);

if ($response->status == 'OK') {
    echo "Intención de pago creada correctamente.";
} else {
    echo "Error: " . $response->error;
}
?>
